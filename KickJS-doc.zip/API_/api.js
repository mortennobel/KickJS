YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "kick.core.BuiltInResourceProvider",
        "kick.core.ChunkData",
        "kick.core.Config",
        "kick.core.Constants",
        "kick.core.Engine",
        "kick.core.EventQueue",
        "kick.core.GLState",
        "kick.core.KeyInput",
        "kick.core.MouseInput",
        "kick.core.Project",
        "kick.core.ProjectAsset",
        "kick.core.ResourceDescriptor",
        "kick.core.ResourceLoader",
        "kick.core.ResourceProvider",
        "kick.core.ResourceTracker",
        "kick.core.Time",
        "kick.core.URLResourceProvider",
        "kick.core.Util",
        "kick.importer.ColladaImporter",
        "kick.importer.ObjImporter",
        "kick.material.GLSLConstants",
        "kick.material.Material",
        "kick.material.MaterialUniform",
        "kick.material.Shader",
        "kick.material.UniformDescriptor",
        "kick.math.Aabb",
        "kick.math.Frustum",
        "kick.math.Mat2",
        "kick.math.Mat2d",
        "kick.math.Mat3",
        "kick.math.Mat4",
        "kick.math.Quat",
        "kick.math.Vec2",
        "kick.math.Vec3",
        "kick.math.Vec4",
        "kick.mesh.Mesh",
        "kick.mesh.MeshData",
        "kick.mesh.MeshDataFactory",
        "kick.scene.Camera",
        "kick.scene.CameraPicking",
        "kick.scene.Component",
        "kick.scene.ComponentChangedListener",
        "kick.scene.EngineUniforms",
        "kick.scene.GameObject",
        "kick.scene.Light",
        "kick.scene.MeshRenderer",
        "kick.scene.PickResult",
        "kick.scene.Scene",
        "kick.scene.SceneLights",
        "kick.scene.Transform",
        "kick.texture.MovieTexture",
        "kick.texture.RenderTexture",
        "kick.texture.Texture"
    ],
    "modules": [
        "kick.core",
        "kick.importer",
        "kick.material",
        "kick.math",
        "kick.mesh",
        "kick.scene",
        "kick.texture"
    ],
    "allModules": [
        {
            "displayName": "kick.core",
            "name": "kick.core"
        },
        {
            "displayName": "kick.importer",
            "name": "kick.importer"
        },
        {
            "displayName": "kick.material",
            "name": "kick.material"
        },
        {
            "displayName": "kick.math",
            "name": "kick.math"
        },
        {
            "displayName": "kick.mesh",
            "name": "kick.mesh"
        },
        {
            "displayName": "kick.scene",
            "name": "kick.scene"
        },
        {
            "displayName": "kick.texture",
            "name": "kick.texture"
        }
    ]
} };
});