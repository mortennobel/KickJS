YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "KICK.core.BuiltInResourceProvider",
        "KICK.core.ChunkData",
        "KICK.core.Config",
        "KICK.core.Constants",
        "KICK.core.Engine",
        "KICK.core.EventQueue",
        "KICK.core.GLState",
        "KICK.core.KeyInput",
        "KICK.core.MouseInput",
        "KICK.core.Project",
        "KICK.core.ProjectAsset",
        "KICK.core.ResourceDescriptor",
        "KICK.core.ResourceLoader",
        "KICK.core.ResourceProvider",
        "KICK.core.ResourceTracker",
        "KICK.core.Time",
        "KICK.core.URLResourceProvider",
        "KICK.core.Util",
        "KICK.importer.ColladaImporter",
        "KICK.importer.ObjImporter",
        "KICK.material.GLSLConstants",
        "KICK.material.Material",
        "KICK.material.MaterialUniform",
        "KICK.material.Shader",
        "KICK.material.UniformDescriptor",
        "KICK.math.aabb",
        "KICK.math.frustum",
        "KICK.math.mat3",
        "KICK.math.mat4",
        "KICK.math.quat4",
        "KICK.math.vec2",
        "KICK.math.vec3",
        "KICK.math.vec4",
        "KICK.mesh.Mesh",
        "KICK.mesh.MeshData",
        "KICK.mesh.MeshFactory",
        "KICK.scene.Camera",
        "KICK.scene.Component",
        "KICK.scene.ComponentChangedListener",
        "KICK.scene.GameObject",
        "KICK.scene.Light",
        "KICK.scene.MeshRenderer",
        "KICK.scene.Scene",
        "KICK.scene.SceneLights",
        "KICK.scene.Transform",
        "KICK.texture.MovieTexture",
        "KICK.texture.RenderTexture",
        "KICK.texture.Texture"
    ],
    "modules": [
        "KICK"
    ],
    "allModules": [
        {
            "displayName": "KICK",
            "name": "KICK",
            "description": "description _"
        }
    ]
} };
});